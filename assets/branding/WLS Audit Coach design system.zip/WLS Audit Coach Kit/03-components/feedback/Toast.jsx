import React from 'react';

/** Inline toast/snackbar bar. kind: neutral | success | error. */
export function Toast({ kind = 'neutral', message, actionLabel, onAction, style }) {
  const icons = { neutral: 'info', success: 'check_circle', error: 'error' };
  const iconColor = { neutral: 'var(--wls-gray-400)', success: 'var(--status-success)', error: '#EB7284' };
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, minHeight: 52, padding: '8px 16px',
      background: 'var(--surface-inverse)', color: 'var(--text-inverse)', borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--elevation-3)', font: 'var(--type-body)', ...style,
    }}>
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 20, color: iconColor[kind] || iconColor.neutral, fontVariationSettings: "'FILL' 1" }}>{icons[kind] || icons.neutral}</span>
      <span style={{ flex: 1 }}>{message}</span>
      {actionLabel ? <button onClick={onAction} style={{ border: 'none', background: 'transparent', color: '#EB7284', font: 'var(--type-label)', letterSpacing: 'var(--tracking-label)', cursor: 'pointer', padding: '8px 4px', textTransform: 'uppercase' }}>{actionLabel}</button> : null}
    </div>
  );
}
