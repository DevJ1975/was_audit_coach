Filter chip row above lists (All / Open / Overdue…). Selected chips go inverse charcoal — red stays reserved for actions and fails.

```jsx
<Chip selected onPress={f}>Open</Chip>
<Chip icon="calendar_month">This week</Chip>
```
