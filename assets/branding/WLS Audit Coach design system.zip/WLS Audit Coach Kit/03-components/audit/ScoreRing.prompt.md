Hero score display on dashboard and audit summaries.

```jsx
<ScoreRing value={92} label="Site score" />
<ScoreRing value={64} size={64} stroke={7} />
```
