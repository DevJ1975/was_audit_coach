import React from 'react';
import { StatusBadge } from './StatusBadge.jsx';
import { ProgressBar } from '../display/ProgressBar.jsx';

/** Audit summary card: template, site, progress or final score. */
export function AuditCard({ title, site, date, status = 'draft', progress, score, findings, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const showScore = typeof score === 'number';
  const band = showScore ? (score >= 90 ? 'var(--score-pass)' : score >= 70 ? 'var(--score-fair)' : 'var(--score-fail)') : null;
  return (
    <div
      onClick={onPress || onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)',
        boxShadow: hover ? 'var(--elevation-2)' : 'var(--elevation-1)', cursor: 'pointer', padding: 16,
        transition: 'box-shadow var(--duration-base) var(--ease-standard)', ...style,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <span style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: '600 16px/22px var(--font-sans)', color: 'var(--text-primary)' }}>{title}</div>
          <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)', marginTop: 2 }}>{[site, date].filter(Boolean).join(' · ')}</div>
        </span>
        {showScore
          ? <span style={{ font: 'var(--type-data-lg)', color: band, flex: 'none' }}>{Math.round(score)}<span style={{ fontSize: 15 }}>%</span></span>
          : <StatusBadge status={status} />}
      </div>
      {typeof progress === 'number' && !showScore ? <ProgressBar value={progress} height={6} style={{ marginTop: 14 }} /> : null}
      {(findings !== undefined || showScore) ? (
        <div style={{ display: 'flex', gap: 14, marginTop: 12, font: 'var(--type-body-sm)', color: 'var(--text-muted)', alignItems: 'center' }}>
          {showScore ? <StatusBadge status={score >= 70 ? 'pass' : 'fail'} label={score >= 90 ? 'Pass' : score >= 70 ? 'Needs attention' : 'Action required'} /> : null}
          {findings !== undefined ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 15 }}>flag</span>{findings} finding{findings === 1 ? '' : 's'}</span> : null}
        </div>
      ) : null}
    </div>
  );
}
