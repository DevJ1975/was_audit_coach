/**
 * Floating action button for the hero action of a screen (e.g. New audit).
 */
export interface FabProps {
  /** Material Symbols icon name, default "add" */
  icon?: string;
  label?: string;
  /** pill with label text */
  extended?: boolean;
  onPress?: () => void;
  style?: React.CSSProperties;
}
export declare function Fab(props: FabProps): JSX.Element;
