Count badge on icons (open findings, unread coaching tips).

```jsx
<Badge count={3}><IconButton icon="notifications" /></Badge>
```
