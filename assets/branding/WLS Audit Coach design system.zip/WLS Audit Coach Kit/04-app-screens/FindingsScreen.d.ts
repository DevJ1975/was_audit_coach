/**
 * Findings & corrective actions list (phone).
 */
export interface FindingsScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function FindingsScreen(props: FindingsScreenProps): JSX.Element;
