import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { IconButton } from '../../03-components/core/IconButton.jsx';
import { SearchBar } from '../../03-components/forms/SearchBar.jsx';
import { Chip } from '../../03-components/core/Chip.jsx';
import { AuditCard } from '../../03-components/audit/AuditCard.jsx';

/** Audits list with search + filter chips. */
export function AuditsScreen({ onNavigate }) {
  const [filter, setFilter] = React.useState('all');
  const go = (r) => onNavigate && onNavigate(r);
  const chips = [
    { key: 'all', label: 'All' }, { key: 'progress', label: 'In progress' },
    { key: 'scheduled', label: 'Scheduled' }, { key: 'done', label: 'Completed' },
  ];
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <AppBar large title="Audits" transparent actions={<IconButton icon="tune" label="Filters" />} />
      <div style={{ padding: '0 16px 90px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <SearchBar placeholder="Search audits, sites, people" />
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 2 }}>
          {chips.map(c => <Chip key={c.key} selected={filter === c.key} onPress={() => setFilter(c.key)}>{c.label}</Chip>)}
        </div>
        <AuditCard title="Weekly safety walkthrough" site="Plant 4 — Zone A–C" date="Today" status="in-progress" progress={62} onPress={() => go('audit')} />
        <AuditCard title="Forklift pre-shift check" site="Plant 4 — Dock 2" date="Today 2:00 PM" status="scheduled" onPress={() => go('audit')} />
        <AuditCard title="Fire safety quarterly" site="Warehouse 2" date="Jul 8" score={94} findings={1} onPress={() => go('audit')} />
        <AuditCard title="Housekeeping — 5S" site="Line 3" date="Jul 7" score={81} findings={2} onPress={() => go('audit')} />
        <AuditCard title="Lockout / tagout review" site="Plant 4 — Maintenance" date="Jul 3" score={67} findings={4} onPress={() => go('audit')} />
      </div>
    </div>
  );
}
