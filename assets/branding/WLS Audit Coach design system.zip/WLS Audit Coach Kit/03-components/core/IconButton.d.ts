/**
 * Icon-only round button for toolbar and app-bar actions.
 */
export interface IconButtonProps {
  /** Material Symbols icon name */
  icon: string;
  variant?: 'standard' | 'tonal' | 'filled';
  /** px, default 44 */
  size?: number;
  /** filled-icon active state */
  active?: boolean;
  disabled?: boolean;
  /** accessible label */
  label?: string;
  onPress?: () => void;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
