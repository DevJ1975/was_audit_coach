import React from 'react';

/** Dropdown select styled to match TextField. options: [{value,label}] or strings. */
export function Select({ label, options = [], value, defaultValue, placeholder, helper, disabled = false, onChange, onValueChange, style }) {
  const [focus, setFocus] = React.useState(false);
  const id = React.useId();
  const opts = options.map(o => typeof o === 'string' ? { value: o, label: o } : o);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label ? <label htmlFor={id} style={{ font: 'var(--type-label)', color: 'var(--text-primary)' }}>{label}</label> : null}
      <div style={{ position: 'relative' }}>
        <select
          id={id} value={value} defaultValue={value !== undefined ? undefined : (defaultValue ?? '')} disabled={disabled}
          onChange={(e) => { onChange && onChange(e); onValueChange && onValueChange(e.target.value); }}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            width: '100%', height: 48, boxSizing: 'border-box', appearance: 'none', WebkitAppearance: 'none',
            font: 'var(--type-body)', fontFamily: 'var(--font-sans)', color: 'var(--text-primary)',
            background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)', padding: '0 40px 0 14px',
            border: focus ? '1.5px solid var(--border-focus)' : '1.5px solid var(--border-strong)',
            borderRadius: 'var(--radius-md)', outline: 'none', boxShadow: focus ? 'var(--focus-ring)' : 'none', cursor: 'pointer',
          }}
        >
          {placeholder ? <option value="" disabled>{placeholder}</option> : null}
          {opts.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 22, position: 'absolute', right: 12, top: 13, color: 'var(--text-muted)', pointerEvents: 'none' }}>expand_more</span>
      </div>
      {helper ? <div style={{ font: 'var(--type-caption)', color: 'var(--text-muted)' }}>{helper}</div> : null}
    </div>
  );
}
