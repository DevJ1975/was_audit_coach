# Audit Coach app — UI kit

Interactive phone recreation of the Audit Coach React Native app. `index.html` is a click-through demo: sign in → dashboard → start an audit from the Audits tab (FAB) → answer checklist items → submit → toast confirmation. Bottom nav covers Home / Audits / Findings / Reports / Coach. Light/dark toggle under the frame.

Screens (each a bundled component):
- **LoginScreen** — stacked lockup, email/password, SSO
- **DashboardScreen** — score ring hero, due-today stats, banner, coach tip, today's audits
- **AuditsScreen** — search, filter chips, audit cards, New-audit FAB
- **AuditRunScreen** — section progress, Pass/Fail/N-A checklist, inline coach tip on fail, submit
- **FindingsScreen** — tabs by state, severity-railed finding cards
- **ReportsScreen** — score trend bars, category breakdown, shared reports, export
- **CoachScreen** — weekly focus tip, recommended micro-lessons, crew completion

Tablet adaptation: keep phone layouts as the column width (~600px max content), promote BottomNav to a left NavigationRail, and show list+detail side-by-side on Audits/Findings. Screen margin becomes 24px.
