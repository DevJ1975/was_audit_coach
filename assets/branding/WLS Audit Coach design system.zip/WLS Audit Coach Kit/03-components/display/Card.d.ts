/**
 * Surface container — 16px radius, elevation-1.
 */
export interface CardProps {
  variant?: 'elevated' | 'outlined' | 'filled';
  /** inner padding px, default 16 */
  padding?: number | string;
  /** makes the card pressable (hover lift) */
  onPress?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
