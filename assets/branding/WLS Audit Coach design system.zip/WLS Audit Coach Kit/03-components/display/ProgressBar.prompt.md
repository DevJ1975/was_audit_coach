Progress for audit completion (brand red) or scores (`scored` → green/amber/red bands).

```jsx
<ProgressBar value={62} label="Sections complete" />
<ProgressBar value={94} scored />
```
