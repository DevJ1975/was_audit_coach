import React from 'react';
import { StatusBadge } from './StatusBadge.jsx';

/** Finding / corrective-action card: severity rail, status, assignee, due date. */
export function FindingCard({ id, title, site, severity = 'major', status = 'open', assignee, due, overdue = false, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const sev = {
    critical: { color: 'var(--wls-red-500)', label: 'Critical' },
    major:    { color: 'var(--score-fair)',  label: 'Major' },
    minor:    { color: 'var(--wls-gray-400)', label: 'Minor' },
  }[severity] || { color: 'var(--wls-gray-400)', label: severity };
  return (
    <div
      onClick={onPress || onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)',
        boxShadow: hover ? 'var(--elevation-2)' : 'var(--elevation-1)', cursor: 'pointer', overflow: 'hidden',
        display: 'flex', transition: 'box-shadow var(--duration-base) var(--ease-standard)', ...style,
      }}
    >
      <span style={{ width: 4, flex: 'none', background: sev.color }}></span>
      <div style={{ padding: '14px 16px', flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span style={{ font: 'var(--type-data)', fontSize: 12, color: 'var(--text-muted)' }}>{id}</span>
          <span style={{ font: '600 12px/16px var(--font-sans)', color: sev.color }}>{sev.label}</span>
          <span style={{ flex: 1 }}></span>
          <StatusBadge status={overdue ? 'overdue' : status} />
        </div>
        <div style={{ font: '600 15px/21px var(--font-sans)', color: 'var(--text-primary)' }}>{title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 8, font: 'var(--type-body-sm)', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
          {site ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 15 }}>location_on</span>{site}</span> : null}
          {assignee ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 15 }}>person</span>{assignee}</span> : null}
          {due ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: overdue ? 'var(--status-danger-text)' : 'var(--text-muted)', fontWeight: overdue ? 600 : 400 }}><span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 15 }}>event</span>{due}</span> : null}
        </div>
      </div>
    </div>
  );
}
