Small view switcher inside a screen (never for navigation — that's Tabs).

```jsx
<SegmentedControl options={['Week', 'Month', 'Quarter']} defaultValue="Month" />
```
