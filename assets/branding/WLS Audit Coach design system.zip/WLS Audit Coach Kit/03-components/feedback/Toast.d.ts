/**
 * Transient snackbar confirmation on inverse surface.
 */
export interface ToastProps {
  kind?: 'neutral' | 'success' | 'error';
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
