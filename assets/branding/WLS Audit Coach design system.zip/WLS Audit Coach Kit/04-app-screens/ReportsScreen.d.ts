/**
 * Reports & analytics screen (phone).
 */
export interface ReportsScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function ReportsScreen(props: ReportsScreenProps): JSX.Element;
