/**
 * Filter/choice chip for list filtering and quick toggles. Selected = inverse charcoal, not red.
 */
export interface ChipProps {
  selected?: boolean;
  /** Material Symbols icon name */
  icon?: string;
  onPress?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Chip(props: ChipProps): JSX.Element;
