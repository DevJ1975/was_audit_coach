/**
 * Standard tappable row for lists and settings.
 */
export interface ListItemProps {
  /** Material Symbols name, shown in a tinted square */
  icon?: string;
  iconColor?: string;
  /** custom leading node (e.g. <Avatar/>) — overrides icon */
  leading?: React.ReactNode;
  title: string;
  subtitle?: string;
  /** custom right-side node (badge, score, switch…) */
  trailing?: React.ReactNode;
  chevron?: boolean;
  divider?: boolean;
  onPress?: () => void;
  style?: React.CSSProperties;
}
export declare function ListItem(props: ListItemProps): JSX.Element;
