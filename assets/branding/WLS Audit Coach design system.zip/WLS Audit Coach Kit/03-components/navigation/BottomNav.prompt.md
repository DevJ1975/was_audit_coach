App-level navigation. Canonical Audit Coach set: Home, Audits, Findings, Reports, Coach.

```jsx
<BottomNav value={tab} onChange={setTab} items={[
  {key:'home', icon:'dashboard', label:'Home'},
  {key:'audits', icon:'checklist', label:'Audits'},
  {key:'findings', icon:'flag', label:'Findings', badge:3},
  {key:'reports', icon:'bar_chart', label:'Reports'},
  {key:'coach', icon:'school', label:'Coach'},
]} />
```
