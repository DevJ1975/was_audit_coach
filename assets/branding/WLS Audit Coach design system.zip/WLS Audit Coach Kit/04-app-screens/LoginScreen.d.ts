/**
 * Audit Coach sign-in screen (phone).
 */
export interface LoginScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function LoginScreen(props: LoginScreenProps): JSX.Element;
