/**
 * Audit summary card for lists — in-progress (progress bar) or completed (score).
 */
export interface AuditCardProps {
  title: string;
  site?: string;
  /** display date string */
  date?: string;
  status?: 'draft' | 'scheduled' | 'in-progress';
  /** 0–100 completion; shown when no score yet */
  progress?: number;
  /** final 0–100 score; switches card to completed layout */
  score?: number;
  /** open findings count */
  findings?: number;
  onPress?: () => void;
  style?: React.CSSProperties;
}
export declare function AuditCard(props: AuditCardProps): JSX.Element;
