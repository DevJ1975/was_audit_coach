/**
 * Inline 2–4 way view switcher (e.g. Week / Month / Quarter).
 */
export interface SegmentedControlProps {
  options: Array<string | { value: string; label: string }>;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}
export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
