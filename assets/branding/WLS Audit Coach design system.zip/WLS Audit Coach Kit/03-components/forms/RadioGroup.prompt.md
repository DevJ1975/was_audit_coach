Single-choice list (audit frequency, severity pick).

```jsx
<RadioGroup defaultValue="weekly" options={[{value:'weekly',label:'Weekly'},{value:'monthly',label:'Monthly'}]} />
```
