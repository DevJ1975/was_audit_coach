import React from 'react';

/** One audit checklist question with Pass / Fail / N/A response and quick actions. */
export function ChecklistItem({ number, question, hint, value, onChange, onPhoto, onNote, photoCount = 0, noteCount = 0, style }) {
  const [internal, setInternal] = React.useState(value);
  const current = value !== undefined ? value : internal;
  const set = (v) => { const next = current === v ? undefined : v; if (value === undefined) setInternal(next); onChange && onChange(next); };
  const opts = [
    { key: 'pass', label: 'Pass', icon: 'check', on: { background: 'var(--score-pass)', color: '#fff', borderColor: 'var(--score-pass)' } },
    { key: 'fail', label: 'Fail', icon: 'close', on: { background: 'var(--score-fail)', color: '#fff', borderColor: 'var(--score-fail)' } },
    { key: 'na',   label: 'N/A',  icon: 'remove', on: { background: 'var(--wls-gray-600)', color: '#fff', borderColor: 'var(--wls-gray-600)' } },
  ];
  return (
    <div style={{ background: 'var(--surface-card)', border: current === 'fail' ? '1.5px solid var(--wls-red-200)' : '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', padding: 16, ...style }}>
      <div style={{ display: 'flex', gap: 10 }}>
        {number !== undefined ? <span style={{ font: 'var(--type-data)', color: 'var(--text-muted)', flex: 'none' }}>{String(number).padStart(2, '0')}</span> : null}
        <span style={{ flex: 1 }}>
          <div style={{ font: '600 15px/21px var(--font-sans)', color: 'var(--text-primary)' }}>{question}</div>
          {hint ? <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)', marginTop: 3 }}>{hint}</div> : null}
        </span>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
        {opts.map(o => {
          const on = current === o.key;
          return (
            <button key={o.key} onClick={() => set(o.key)} style={{
              flex: 1, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              font: 'var(--type-label)', letterSpacing: 'var(--tracking-label)', cursor: 'pointer',
              borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border-strong)',
              background: 'var(--surface-card)', color: 'var(--text-secondary)',
              transition: 'all var(--duration-fast) var(--ease-standard)',
              ...(on ? o.on : {}), ...(on ? { border: '1.5px solid ' + o.on.borderColor } : {}),
            }}>
              <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 17, lineHeight: 1, fontVariationSettings: "'wght' 600" }}>{o.icon}</span>
              {o.label}
            </button>
          );
        })}
      </div>
      <div style={{ display: 'flex', gap: 4, marginTop: 10 }}>
        <button onClick={onPhoto} style={{ display: 'flex', alignItems: 'center', gap: 6, border: 'none', background: 'transparent', color: 'var(--text-muted)', font: 'var(--type-body-sm)', cursor: 'pointer', padding: '6px 8px', borderRadius: 8 }}>
          <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 18 }}>photo_camera</span>{photoCount > 0 ? photoCount : 'Photo'}
        </button>
        <button onClick={onNote} style={{ display: 'flex', alignItems: 'center', gap: 6, border: 'none', background: 'transparent', color: 'var(--text-muted)', font: 'var(--type-body-sm)', cursor: 'pointer', padding: '6px 8px', borderRadius: 8 }}>
          <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 18 }}>edit_note</span>{noteCount > 0 ? noteCount : 'Note'}
        </button>
      </div>
    </div>
  );
}
