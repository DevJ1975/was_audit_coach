import React from 'react';

/** Primary action button. variant: primary | secondary | ghost | danger. size: sm | md | lg. */
export function Button({ variant = 'primary', size = 'md', icon, disabled = false, fullWidth = false, children, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const sizes = {
    sm: { height: 36, pad: '0 14px', font: 'var(--type-label)', iconSize: 18, radius: 'var(--radius-sm)' },
    md: { height: 44, pad: '0 18px', font: '600 15px/20px var(--font-sans)', iconSize: 20, radius: 'var(--radius-md)' },
    lg: { height: 52, pad: '0 24px', font: '600 17px/22px var(--font-sans)', iconSize: 22, radius: 'var(--radius-md)' },
  };
  const s = sizes[size] || sizes.md;
  const palettes = {
    primary: {
      bg: press ? 'var(--color-primary-pressed)' : hover ? 'var(--color-primary-hover)' : 'var(--color-primary)',
      fg: 'var(--color-on-primary)', border: '1.5px solid transparent',
    },
    secondary: {
      bg: press ? 'var(--surface-sunken)' : hover ? 'var(--wls-gray-50)' : 'var(--surface-card)',
      fg: 'var(--text-primary)', border: '1.5px solid var(--border-strong)',
    },
    ghost: {
      bg: press || hover ? 'var(--color-primary-subtle)' : 'transparent',
      fg: 'var(--text-brand)', border: '1.5px solid transparent',
    },
    danger: {
      bg: press ? 'var(--wls-red-700)' : hover ? 'var(--wls-red-600)' : 'var(--wls-red-500)',
      fg: '#FFFFFF', border: '1.5px solid transparent',
    },
  };
  const p = palettes[variant] || palettes.primary;
  return (
    <button
      onClick={onPress || onClick}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        height: s.height, padding: s.pad, font: s.font, letterSpacing: 'var(--tracking-label)',
        color: p.fg, background: p.bg, border: p.border, borderRadius: s.radius,
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1,
        width: fullWidth ? '100%' : undefined, transition: 'background var(--duration-fast) var(--ease-standard)',
        transform: press && !disabled ? 'scale(0.98)' : 'none', userSelect: 'none', whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {icon ? <span className="ms" aria-hidden style={{ fontFamily: 'Material Symbols Rounded', fontSize: s.iconSize, lineHeight: 1, fontVariationSettings: "'FILL' 0, 'wght' 500, 'GRAD' 0, 'opsz' 24" }}>{icon}</span> : null}
      {children}
    </button>
  );
}
