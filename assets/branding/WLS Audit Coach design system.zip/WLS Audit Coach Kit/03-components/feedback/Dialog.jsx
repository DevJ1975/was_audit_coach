import React from 'react';

/** Modal dialog. Render when open; fills nearest positioned ancestor (or viewport). */
export function Dialog({ open = true, icon, title, children, actions, onClose, destructive = false, style }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'var(--surface-overlay)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 40 }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: 340, background: 'var(--surface-raised)', borderRadius: 'var(--radius-xl)',
        padding: 24, boxShadow: 'var(--elevation-3)', ...style,
      }}>
        {icon ? <span style={{ width: 44, height: 44, borderRadius: '50%', background: destructive ? 'var(--status-danger-bg)' : 'var(--color-primary-subtle)', color: destructive ? 'var(--status-danger-text)' : 'var(--text-brand)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
          <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 24 }}>{icon}</span>
        </span> : null}
        <div style={{ font: 'var(--type-title)', color: 'var(--text-primary)', marginBottom: 8 }}>{title}</div>
        <div style={{ font: 'var(--type-body)', color: 'var(--text-secondary)' }}>{children}</div>
        {actions ? <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>{actions}</div> : null}
      </div>
    </div>
  );
}
