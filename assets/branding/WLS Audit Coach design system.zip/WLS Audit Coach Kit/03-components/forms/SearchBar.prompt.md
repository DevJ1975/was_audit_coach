Pill search above lists.

```jsx
<SearchBar placeholder="Search audits, sites, people" onChangeText={setQuery} />
```
