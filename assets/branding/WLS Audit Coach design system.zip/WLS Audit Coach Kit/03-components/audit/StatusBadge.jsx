import React from 'react';

/** Pill status label. status: pass | fail | na | open | in-progress | resolved | overdue | draft | scheduled. */
export function StatusBadge({ status = 'open', label, style }) {
  const map = {
    'pass':        { bg: 'var(--status-success-bg)', fg: 'var(--status-success-text)', icon: 'check_circle', text: 'Pass' },
    'fail':        { bg: 'var(--status-danger-bg)',  fg: 'var(--status-danger-text)',  icon: 'cancel',       text: 'Fail' },
    'na':          { bg: 'var(--surface-sunken)',    fg: 'var(--text-muted)',          icon: 'do_not_disturb_on', text: 'N/A' },
    'open':        { bg: 'var(--status-danger-bg)',  fg: 'var(--status-danger-text)',  icon: 'flag',         text: 'Open' },
    'in-progress': { bg: 'var(--status-info-bg)',    fg: 'var(--status-info-text)',    icon: 'progress_activity', text: 'In progress' },
    'resolved':    { bg: 'var(--status-success-bg)', fg: 'var(--status-success-text)', icon: 'task_alt',     text: 'Resolved' },
    'overdue':     { bg: 'var(--wls-red-500)',       fg: '#FFFFFF',                    icon: 'schedule',     text: 'Overdue' },
    'draft':       { bg: 'var(--surface-sunken)',    fg: 'var(--text-secondary)',      icon: 'edit_note',    text: 'Draft' },
    'scheduled':   { bg: 'var(--status-info-bg)',    fg: 'var(--status-info-text)',    icon: 'event',        text: 'Scheduled' },
  };
  const m = map[status] || map.open;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, height: 24, padding: '0 10px',
      background: m.bg, color: m.fg, borderRadius: 'var(--radius-full)',
      font: '600 12px/16px var(--font-sans)', letterSpacing: '0.01em', whiteSpace: 'nowrap', ...style,
    }}>
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 14, lineHeight: 1, fontVariationSettings: "'FILL' 1" }}>{m.icon}</span>
      {label || m.text}
    </span>
  );
}
