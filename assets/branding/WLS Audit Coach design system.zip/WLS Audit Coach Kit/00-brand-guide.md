# WLS Audit Coach — Design System

Brand and UI system for **Audit Coach**, the audit SaaS platform by **Workplace Learning System (WLS)**. React Native app (phone + tablet), used equally by field auditors and safety/compliance managers. Material-informed but brand-first. Light + dark themes.

**Source material:** the WLS globe logo (`uploads/Workplace LS logo_globe_homepg150(1).jpg`), retraced as vector in `assets/logo/`. No other brand assets were provided; everything else is derived from the logo's red / charcoal / silver palette.

## CONTENT FUNDAMENTALS

Voice = **a supportive coach**: encouraging, plain, human. Celebrates progress, never scolds.

- **Sentence case** everywhere — titles, buttons, labels. No Title Case, no ALL CAPS except overlines (`SECTION 2 OF 4`).
- **"You/your"** for the user, **"we"** rarely (only for system actions). First names for people ("Morning, Maria").
- Short verb-first actions: "Start audit", "Review now", "Save draft". Never "Submit Form" or "OK".
- Positive framing of data: "Ladder findings dropped 40% since May", "+4 pts vs June". Failures are "findings" and "nice catch" moments, not violations.
- Empty states encourage: "All caught up — nice work keeping things tight."
- Errors say what to do next: "Badge ID not found — double-check the card."
- **No emoji.** No exclamation marks except a rare single one in celebration copy.
- Numbers are precise and mono-set (92%, F-1042, AUD-2419).

## VISUAL FOUNDATIONS

- **Colors:** red `#CE1F30` is the single accent — the one main action, active nav, brand moments, and *fail/danger* (deliberately the same family; audits treat red as "act now"). Everything else is the silver/charcoal neutral ramp. Green/amber exist only as score/status hues; blue only for info. 1 red accent per view, generous whitespace.
- **Score bands:** pass ≥90 green, fair 70–89 amber, fail <70 red, N/A gray — used identically in rings, bars, badges.
- **Type:** Source Sans 3 for all UI (400/500/600/700); IBM Plex Mono for scores, IDs, timestamps; Georgia is *logo-only*. Scale in `tokens/typography.css` (display 34 → caption 12; body 15).
- **Spacing:** 4px grid (`--space-1..10`); screen margin 16 phone / 24 tablet; hit targets ≥44px.
- **Corners:** buttons/inputs 12, cards 16, dialogs 24, pills/chips full. Sub-8px only for tiny elements.
- **Backgrounds:** flat `--surface-page` gray with white cards. No gradients, no textures, no full-bleed imagery; the only decorative flourish is the subtle red wash on CoachTip.
- **Elevation:** whisper-quiet — elevation-1 on resting cards + 1px border; elevation-2 on hover/press lift; elevation-3 dialogs only. Dark theme uses deeper shadows and lighter surfaces instead of borders alone.
- **Borders:** 1px `--border-default` on cards; 1.5px `--border-strong` on inputs/chips; focus = red border + 3px soft red ring.
- **States:** hover = one surface step darker (or elevation-2 lift on cards); press = darker still + scale(0.98); selected chips go inverse charcoal (red stays reserved); active nav = filled icon + red tint pill.
- **Motion:** `cubic-bezier(.2,0,0,1)`, 120/200/320ms. Fades and small translates; progress animates width/offset. No bounces.
- **Dark theme:** `data-theme="dark"` remaps all semantic tokens; the primary red lightens to `#E4576B` for contrast.
- **Severity rail:** findings carry a 4px left rail — critical red / major amber / minor gray.

## ICONOGRAPHY

- **Icon system:** [Material Symbols Rounded](https://fonts.google.com/icons) variable font, loaded via `tokens/fonts.css` (CDN). Default: 24px optical size, weight 400, FILL 0. **Active/selected = FILL 1.** In RN use `@expo/vector-icons` MaterialSymbols or react-native-vector-icons equivalent.
- Canonical names: dashboard, checklist, flag, bar_chart, school, photo_camera, edit_note, mic, check_circle, error, warning, info, location_on, person, event, tune, ios_share, download.
- **Logo assets** (`assets/logo/`): `wls-globe.svg` (master mark), `wls-lockup-horizontal.svg` (retraced original WLS lockup), `audit-coach-lockup-h.svg` + `audit-coach-lockup-stacked.svg` (product lockups), `app-icon-light/dark.svg` (SaaS app icon), `wls-glyph-mono.svg` + charcoal/white/red variants (flat glyph, seams knock out for small sizes / favicons), PNG exports in `assets/logo/png/` (1024/512/192/128/48).
- Globe minimum size 24px; below that use the flat glyph. Keep clear space = ¼ globe diameter. Never recolor the 4-blade mark; use glyph variants instead.
- No emoji, no hand-drawn SVGs, no unicode-as-icon.

## INDEX

- `styles.css` — global entry; imports `tokens/` (fonts, colors, typography, spacing, elevation)
- `tokens/` — CSS custom properties (light + dark)
- `react-native/theme.js` — the same tokens as a JS theme + React Native Paper (MD3) adapter
- `assets/logo/` — retraced logo set (SVG masters + PNG exports)
- `guidelines/` — foundation specimen cards (brand, colors, type, spacing, icons)
- `components/` — 26 primitives with `.d.ts` + `.prompt.md`:
  - `core/` Button, IconButton, Fab, Chip, Badge
  - `forms/` TextField, Select, Checkbox, RadioGroup, Switch, SearchBar, SegmentedControl
  - `display/` Card, ListItem, Avatar, ProgressBar, EmptyState
  - `navigation/` AppBar, BottomNav, Tabs
  - `feedback/` Dialog, Toast, Banner, Tooltip
  - `audit/` ScoreRing, StatusBadge, ChecklistItem, AuditCard, FindingCard, CoachTip
- `ui_kits/audit_coach_app/` — interactive phone demo (`index.html`) + 7 screen components

**Intentional additions** (no component source was provided, so the set was authored from scratch): the `audit/` family (ScoreRing, StatusBadge, ChecklistItem, AuditCard, FindingCard, CoachTip) encodes the product's audit domain; everything else is the standard primitive set.

**Font note:** no brand font files were provided. Source Sans 3 + IBM Plex Mono (Google Fonts, CDN) were chosen to pair with the logo's humanist-serif wordmark. Supply licensed font files to replace the CDN imports in `tokens/fonts.css`.
