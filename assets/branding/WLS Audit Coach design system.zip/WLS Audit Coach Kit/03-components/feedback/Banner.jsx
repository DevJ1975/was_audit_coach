import React from 'react';

/** Persistent inline banner. kind: info | success | warning | danger. */
export function Banner({ kind = 'info', title, children, actionLabel, onAction, onDismiss, style }) {
  const map = {
    info:    { bg: 'var(--status-info-bg)',    fg: 'var(--status-info-text)',    icon: 'info' },
    success: { bg: 'var(--status-success-bg)', fg: 'var(--status-success-text)', icon: 'check_circle' },
    warning: { bg: 'var(--status-warning-bg)', fg: 'var(--status-warning-text)', icon: 'warning' },
    danger:  { bg: 'var(--status-danger-bg)',  fg: 'var(--status-danger-text)',  icon: 'error' },
  };
  const m = map[kind] || map.info;
  return (
    <div style={{ display: 'flex', gap: 12, padding: '12px 14px', background: m.bg, borderRadius: 'var(--radius-md)', alignItems: 'flex-start', ...style }}>
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 20, color: m.fg, fontVariationSettings: "'FILL' 1", marginTop: 1 }}>{m.icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}>
        {title ? <div style={{ font: 'var(--type-label)', color: m.fg, marginBottom: 2 }}>{title}</div> : null}
        <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-secondary)' }}>{children}</div>
        {actionLabel ? <button onClick={onAction} style={{ border: 'none', background: 'transparent', padding: 0, marginTop: 6, color: m.fg, font: 'var(--type-label)', cursor: 'pointer', textDecoration: 'underline' }}>{actionLabel}</button> : null}
      </span>
      {onDismiss ? <button onClick={onDismiss} aria-label="Dismiss" style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--text-muted)', padding: 2 }}><span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 18 }}>close</span></button> : null}
    </div>
  );
}
