/**
 * Finding / corrective action summary card with severity rail.
 */
export interface FindingCardProps {
  /** e.g. "F-1042" */
  id?: string;
  title: string;
  site?: string;
  severity?: 'critical' | 'major' | 'minor';
  status?: 'open' | 'in-progress' | 'resolved';
  assignee?: string;
  /** display string, e.g. "Due Fri, Jul 18" */
  due?: string;
  overdue?: boolean;
  onPress?: () => void;
  style?: React.CSSProperties;
}
export declare function FindingCard(props: FindingCardProps): JSX.Element;
