/**
 * Audits list screen with filters (phone).
 */
export interface AuditsScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function AuditsScreen(props: AuditsScreenProps): JSX.Element;
