import React from 'react';

/** Surface card. variant: elevated | outlined | filled. */
export function Card({ variant = 'elevated', padding = 16, onPress, onClick, children, style }) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!(onPress || onClick);
  const variants = {
    elevated: { background: 'var(--surface-card)', border: '1px solid var(--border-default)', boxShadow: hover && interactive ? 'var(--elevation-2)' : 'var(--elevation-1)' },
    outlined: { background: 'var(--surface-card)', border: '1.5px solid var(--border-default)', boxShadow: 'none' },
    filled: { background: 'var(--surface-sunken)', border: '1px solid transparent', boxShadow: 'none' },
  };
  return (
    <div
      onClick={onPress || onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        borderRadius: 'var(--radius-lg)', padding, ...( variants[variant] || variants.elevated ),
        cursor: interactive ? 'pointer' : 'default',
        transition: 'box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)',
        transform: hover && interactive ? 'translateY(-1px)' : 'none', ...style,
      }}
    >{children}</div>
  );
}
