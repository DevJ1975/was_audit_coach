Standard form input, 48px tall, 12px radius.

```jsx
<TextField label="Work email" icon="mail" placeholder="you@company.com" />
<TextField label="Notes" multiline helper="Visible to the site manager." />
<TextField label="Badge ID" error="Badge ID not found — double-check the card." />
```
