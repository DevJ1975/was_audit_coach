import React from 'react';

/** Circular audit score. Color follows score bands: pass ≥90, fair 70–89, fail <70. */
export function ScoreRing({ value = 0, size = 96, stroke = 9, label, style }) {
  const band = value >= 90 ? 'var(--score-pass)' : value >= 70 ? 'var(--score-fair)' : 'var(--score-fail)';
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.max(0, Math.min(100, value)) / 100);
  return (
    <div style={{ width: size, position: 'relative', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', ...style }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--score-track)" strokeWidth={stroke} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={band} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={off} style={{ transition: 'stroke-dashoffset var(--duration-slow) var(--ease-standard)' }} />
      </svg>
      <div style={{ position: 'absolute', top: 0, left: 0, width: size, height: size, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ font: `600 ${Math.round(size * 0.26)}px/1 var(--font-mono)`, color: 'var(--text-primary)' }}>{Math.round(value)}<span style={{ fontSize: Math.round(size * 0.14) }}>%</span></span>
        {label ? <span style={{ font: 'var(--type-caption)', color: 'var(--text-muted)', marginTop: 2 }}>{label}</span> : null}
      </div>
    </div>
  );
}
