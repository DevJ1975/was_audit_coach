/**
 * Circular score gauge colored by audit score band.
 */
export interface ScoreRingProps {
  /** 0–100 */
  value: number;
  /** px, default 96 */
  size?: number;
  stroke?: number;
  /** small caption inside the ring */
  label?: string;
  style?: React.CSSProperties;
}
export declare function ScoreRing(props: ScoreRingProps): JSX.Element;
