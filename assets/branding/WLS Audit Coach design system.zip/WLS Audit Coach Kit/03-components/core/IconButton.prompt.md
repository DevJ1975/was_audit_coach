Round icon-only button for app bars, toolbars, and inline actions.

```jsx
<IconButton icon="photo_camera" label="Add photo" onPress={snap} />
<IconButton icon="notifications" variant="tonal" active />
```
