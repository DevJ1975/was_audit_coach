import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { IconButton } from '../../03-components/core/IconButton.jsx';
import { SegmentedControl } from '../../03-components/forms/SegmentedControl.jsx';
import { Card } from '../../03-components/display/Card.jsx';
import { ListItem } from '../../03-components/display/ListItem.jsx';
import { ProgressBar } from '../../03-components/display/ProgressBar.jsx';
import { Button } from '../../03-components/core/Button.jsx';

/** Reports & analytics: score trend, category breakdown, export. */
export function ReportsScreen() {
  const months = [{ m: 'Feb', v: 78 }, { m: 'Mar', v: 82 }, { m: 'Apr', v: 80 }, { m: 'May', v: 86 }, { m: 'Jun', v: 88 }, { m: 'Jul', v: 92 }];
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <AppBar large title="Reports" transparent actions={<IconButton icon="ios_share" label="Share" />} />
      <div style={{ padding: '0 16px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <SegmentedControl options={['Week', 'Month', 'Quarter']} defaultValue="Month" />
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <span style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)' }}>Score trend</span>
            <span style={{ font: 'var(--type-data)', color: 'var(--score-pass)' }}>92%</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 110 }}>
            {months.map((d, i) => (
              <div key={d.m} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, height: '100%', justifyContent: 'flex-end' }}>
                <div style={{ width: '100%', maxWidth: 34, height: d.v + '%', borderRadius: '6px 6px 2px 2px', background: i === months.length - 1 ? 'var(--color-primary)' : 'var(--wls-gray-200)', transition: 'height var(--duration-slow) var(--ease-standard)' }}></div>
                <span style={{ font: 'var(--type-caption)', color: i === months.length - 1 ? 'var(--text-brand)' : 'var(--text-muted)', fontWeight: i === months.length - 1 ? 700 : 400 }}>{d.m}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)', marginBottom: 12 }}>By category</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <ProgressBar value={96} scored label="Fire safety" />
            <ProgressBar value={91} scored label="PPE compliance" />
            <ProgressBar value={84} scored label="Housekeeping" />
            <ProgressBar value={68} scored label="Lockout / tagout" />
          </div>
        </Card>
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <ListItem icon="picture_as_pdf" title="June site report" subtitle="Shared with 8 managers · Jul 1" chevron onPress={() => {}} />
          <ListItem icon="picture_as_pdf" title="Q2 compliance summary" subtitle="Shared with region · Jun 30" divider={false} chevron onPress={() => {}} />
        </Card>
        <Button variant="secondary" icon="download" fullWidth>Export July report</Button>
      </div>
    </div>
  );
}
