import React from 'react';

/** Toggle switch with optional label row. */
export function Switch({ checked, defaultChecked = false, label, description, disabled = false, onChange, style }) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = checked !== undefined ? checked : internal;
  const toggle = () => { if (disabled) return; const v = !on; if (checked === undefined) setInternal(v); onChange && onChange(v); };
  const track = (
    <span role="switch" aria-checked={on} onClick={label ? undefined : toggle} style={{
      width: 48, height: 28, borderRadius: 'var(--radius-full)', flex: 'none', position: 'relative', display: 'inline-block',
      background: on ? 'var(--color-primary)' : 'var(--wls-gray-300)', cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background var(--duration-base) var(--ease-standard)',
    }}>
      <span style={{
        position: 'absolute', top: 3, left: on ? 23 : 3, width: 22, height: 22, borderRadius: '50%',
        background: '#fff', boxShadow: '0 1px 3px rgba(19,20,23,.25)', transition: 'left var(--duration-base) var(--ease-standard)',
      }}></span>
    </span>
  );
  if (!label) return <span style={{ opacity: disabled ? 0.45 : 1, display: 'inline-flex', ...style }}>{track}</span>;
  return (
    <div onClick={toggle} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1, ...style }}>
      <span>
        <div style={{ font: 'var(--type-body)', color: 'var(--text-primary)' }}>{label}</div>
        {description ? <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)' }}>{description}</div> : null}
      </span>
      {track}
    </div>
  );
}
