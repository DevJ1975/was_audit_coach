/**
 * Bottom tab navigation, 3–5 destinations.
 */
export interface BottomNavProps {
  items: Array<{ key: string; icon: string; label: string; badge?: number | string }>;
  /** active item key */
  value: string;
  onChange?: (key: string) => void;
  style?: React.CSSProperties;
}
export declare function BottomNav(props: BottomNavProps): JSX.Element;
