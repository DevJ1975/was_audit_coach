import React from 'react';

/** Initials or image avatar. */
export function Avatar({ name = '', src, size = 40, style }) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  const hues = ['var(--wls-red-500)', 'var(--wls-gray-700)', 'var(--wls-blue-500)', 'var(--wls-green-500)', 'var(--wls-amber-500)'];
  let h = 0; for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 997;
  const bg = hues[h % hues.length];
  return src ? (
    <img src={src} alt={name} style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover', flex: 'none', ...style }} />
  ) : (
    <span aria-label={name} style={{
      width: size, height: size, borderRadius: '50%', background: bg, color: '#fff', flex: 'none',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      font: `600 ${Math.round(size * 0.38)}px/1 var(--font-sans)`, letterSpacing: '0.02em', ...style,
    }}>{initials || '?'}</span>
  );
}
