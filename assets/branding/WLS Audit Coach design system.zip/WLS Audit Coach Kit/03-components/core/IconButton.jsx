import React from 'react';

/** Square icon-only button. variant: standard | tonal | filled. */
export function IconButton({ icon, variant = 'standard', size = 44, active = false, disabled = false, label, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const bg = variant === 'filled' ? 'var(--color-primary)'
    : variant === 'tonal' ? 'var(--color-primary-subtle)'
    : hover ? 'var(--surface-sunken)' : 'transparent';
  const fg = variant === 'filled' ? 'var(--color-on-primary)' : active ? 'var(--text-brand)' : 'var(--text-secondary)';
  const fvs = "'FILL' " + (active ? 1 : 0) + ", 'wght' 400, 'GRAD' 0, 'opsz' 24";
  return (
    <button
      aria-label={label || icon} title={label} onClick={onPress || onClick} disabled={disabled}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        width: size, height: size, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: bg, color: fg, border: 'none', borderRadius: 'var(--radius-full)',
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1,
        transition: 'background var(--duration-fast) var(--ease-standard)', ...style,
      }}
    >
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: Math.round(size * 0.52), lineHeight: 1, fontVariationSettings: fvs }}>{icon}</span>
    </button>
  );
}
