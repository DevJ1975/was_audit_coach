/**
 * Linear progress / score bar.
 */
export interface ProgressBarProps {
  /** 0–100 */
  value: number;
  /** color by score band (pass ≥90, fair ≥70, fail <70) instead of brand red */
  scored?: boolean;
  /** explicit override color */
  color?: string;
  height?: number;
  /** caption row above with percent readout */
  label?: string;
  style?: React.CSSProperties;
}
export declare function ProgressBar(props: ProgressBarProps): JSX.Element;
