/**
 * Encouraging coaching callout — the product voice made visible.
 */
export interface CoachTipProps {
  title?: string;
  children: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  compact?: boolean;
  style?: React.CSSProperties;
}
export declare function CoachTip(props: CoachTipProps): JSX.Element;
