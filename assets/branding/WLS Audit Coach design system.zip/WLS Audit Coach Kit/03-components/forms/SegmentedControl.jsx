import React from 'react';

/** 2–4 segment switcher. options: strings or {value,label}. */
export function SegmentedControl({ options = [], value, defaultValue, onChange, style }) {
  const opts = options.map(o => typeof o === 'string' ? { value: o, label: o } : o);
  const [internal, setInternal] = React.useState(defaultValue ?? (opts[0] && opts[0].value));
  const current = value !== undefined ? value : internal;
  return (
    <div style={{ display: 'flex', background: 'var(--surface-sunken)', borderRadius: 'var(--radius-md)', padding: 3, gap: 2, ...style }}>
      {opts.map(o => {
        const on = current === o.value;
        return (
          <button key={o.value}
            onClick={() => { if (value === undefined) setInternal(o.value); onChange && onChange(o.value); }}
            style={{
              flex: 1, height: 36, border: 'none', borderRadius: 9, cursor: 'pointer',
              font: 'var(--type-label)', letterSpacing: 'var(--tracking-label)',
              background: on ? 'var(--surface-card)' : 'transparent',
              color: on ? 'var(--text-primary)' : 'var(--text-muted)',
              boxShadow: on ? 'var(--elevation-1)' : 'none', transition: 'all var(--duration-fast) var(--ease-standard)', whiteSpace: 'nowrap', padding: '0 12px',
            }}>{o.label}</button>
        );
      })}
    </div>
  );
}
