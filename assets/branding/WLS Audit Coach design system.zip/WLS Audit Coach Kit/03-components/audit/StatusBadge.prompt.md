Lifecycle pill on cards and rows. `overdue` is the only solid-red badge.

```jsx
<StatusBadge status="pass" />
<StatusBadge status="overdue" label="2 days overdue" />
```
