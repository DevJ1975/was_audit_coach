/**
 * Audit question card with Pass / Fail / N/A response and photo/note quick actions.
 */
export interface ChecklistItemProps {
  number?: number;
  question: string;
  /** helper text under the question */
  hint?: string;
  value?: 'pass' | 'fail' | 'na';
  onChange?: (value: 'pass' | 'fail' | 'na' | undefined) => void;
  onPhoto?: () => void;
  onNote?: () => void;
  photoCount?: number;
  noteCount?: number;
  style?: React.CSSProperties;
}
export declare function ChecklistItem(props: ChecklistItemProps): JSX.Element;
