// WLS DS loader: prefers the compiled _ds_bundle.js namespace; falls back to
// fetching + Babel-transforming the component .jsx sources directly.
window.__wlsDS = async function (root, entries) {
  function findBundleNS() {
    for (const k of Object.getOwnPropertyNames(window)) {
      try {
        const v = window[k];
        if (v && typeof v === 'object' && typeof v.Button === 'function' && typeof v.AppBar === 'function') return v;
      } catch (e) { continue; }
    }
    return null;
  }
  let ns = findBundleNS();
  if (!ns) {
    try {
      const r = await fetch(root + '_ds_bundle.js');
      if (r.ok) { (0, eval)(await r.text()); ns = findBundleNS(); }
    } catch (e) { /* no bundle yet */ }
  }
  if (ns) {
    // bundle may not include everything requested (e.g. UI-kit screens); verify
    const missing = (entries || []).some(p => {
      const stem = p.split('/').pop().replace(/\.jsx$/, '');
      return typeof ns[stem] !== 'function';
    });
    if (!missing) return ns;
  }
  // ---- manual module loader (handles our authoring conventions) ----
  const mods = {};
  function resolve(from, rel) {
    const parts = from.split('/').slice(0, -1);
    for (const seg of rel.split('/')) {
      if (seg === '.' || seg === '') continue;
      if (seg === '..') parts.pop(); else parts.push(seg);
    }
    return parts.join('/');
  }
  async function load(path) {
    if (mods[path]) return mods[path];
    const res = await fetch(root + path);
    if (!res.ok) throw new Error('Could not load ' + path);
    let src = await res.text();
    const deps = [];
    src = src.replace(/import\s+React\s+from\s+'react';?/g, '');
    src = src.replace(/import\s+\{([^}]+)\}\s+from\s+'([^']+)';?/g, function (m, names, rel) {
      const r = resolve(path, rel);
      deps.push(r);
      return 'const {' + names + '} = __mods["' + r + '"];';
    });
    src = src.replace(/export\s+function\s+([A-Za-z0-9_]+)/g, '__exports.$1 = $1; function $1');
    for (const d of deps) await load(d);
    const code = Babel.transform(src, { presets: [['react', { runtime: 'classic' }]] }).code;
    const __exports = {};
    new Function('React', '__mods', '__exports', code)(window.React, mods, __exports);
    mods[path] = __exports;
    return __exports;
  }
  const out = {};
  for (const e of entries) Object.assign(out, await load(e));
  for (const p in mods) Object.assign(out, mods[p]);
  return Object.assign(out, ns || {});
};

// Manual runner for page scripts (avoids Babel auto-run's automatic JSX runtime,
// whose emitted import statements can't execute outside a module).
window.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('script[type="text/wls-babel"]').forEach(function (s) {
    try {
      var code = Babel.transform(s.textContent, { presets: [['react', { runtime: 'classic' }]] }).code;
      (0, eval)(code);
    } catch (e) {
      console.error('WLS page script failed:', e);
      var r = document.getElementById('root');
      if (r && !r.innerHTML) r.innerHTML = '<em style="font:13px sans-serif;color:#83878D">Render failed: ' + String(e).replace(/</g, '&lt;') + '</em>';
    }
  });
});
