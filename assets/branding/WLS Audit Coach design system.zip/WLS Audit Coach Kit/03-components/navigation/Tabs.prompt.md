Section tabs inside a screen (Open / In review / Closed).

```jsx
<Tabs tabs={[{value:'open',label:'Open',count:7},{value:'closed',label:'Closed'}]} defaultValue="open" />
```
