import React from 'react';

/** Rounded search field. */
export function SearchBar({ placeholder = 'Search', value, defaultValue, onChangeText, onChange, style }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, height: 46, padding: '0 16px',
      background: 'var(--surface-sunken)', borderRadius: 'var(--radius-full)',
      border: focus ? '1.5px solid var(--border-focus)' : '1.5px solid transparent',
      boxShadow: focus ? 'var(--focus-ring)' : 'none', transition: 'box-shadow var(--duration-fast) var(--ease-standard)',
      boxSizing: 'border-box', ...style,
    }}>
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 20, color: 'var(--text-muted)' }}>search</span>
      <input
        value={value} defaultValue={defaultValue} placeholder={placeholder}
        onChange={(e) => { onChange && onChange(e); onChangeText && onChangeText(e.target.value); }}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', font: 'var(--type-body)', fontFamily: 'var(--font-sans)', color: 'var(--text-primary)', minWidth: 0 }}
      />
    </div>
  );
}
