import React from 'react';

/** Hover/focus tooltip wrapper. */
export function Tooltip({ text, position = 'top', children, style }) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top:    { bottom: '100%', left: '50%', transform: 'translate(-50%, -6px)' },
    bottom: { top: '100%',    left: '50%', transform: 'translate(-50%, 6px)' },
    left:   { right: '100%',  top: '50%',  transform: 'translate(-6px, -50%)' },
    right:  { left: '100%',   top: '50%',  transform: 'translate(6px, -50%)' },
  };
  return (
    <span style={{ position: 'relative', display: 'inline-flex', ...style }}
      onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      {show ? (
        <span role="tooltip" style={{
          position: 'absolute', ...(pos[position] || pos.top), zIndex: 50,
          background: 'var(--surface-inverse)', color: 'var(--text-inverse)', font: 'var(--type-caption)',
          padding: '6px 10px', borderRadius: 'var(--radius-sm)', whiteSpace: 'nowrap', boxShadow: 'var(--elevation-2)', pointerEvents: 'none',
        }}>{text}</span>
      ) : null}
    </span>
  );
}
