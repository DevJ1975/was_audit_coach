/**
 * Dropdown select matching TextField chrome.
 */
export interface SelectProps {
  label?: string;
  options: Array<string | { value: string; label: string }>;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  helper?: string;
  disabled?: boolean;
  onValueChange?: (value: string) => void;
  onChange?: (e: any) => void;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;
