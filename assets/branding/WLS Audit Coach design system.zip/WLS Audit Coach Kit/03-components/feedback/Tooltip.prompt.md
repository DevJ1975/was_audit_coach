Label for icon-only actions.

```jsx
<Tooltip text="Export PDF"><IconButton icon="download" /></Tooltip>
```
