import React from 'react';

/** Tappable list row: icon/avatar slot, title, subtitle, trailing slot or chevron. */
export function ListItem({ icon, iconColor, leading, title, subtitle, trailing, chevron = false, divider = true, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!(onPress || onClick);
  return (
    <div
      onClick={onPress || onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 14, minHeight: 60, padding: '10px 16px',
        background: hover && interactive ? 'var(--surface-sunken)' : 'transparent',
        borderBottom: divider ? '1px solid var(--border-default)' : 'none',
        cursor: interactive ? 'pointer' : 'default', transition: 'background var(--duration-fast) var(--ease-standard)', ...style,
      }}
    >
      {leading || (icon ? (
        <span style={{ width: 40, height: 40, flex: 'none', borderRadius: 'var(--radius-md)', background: 'var(--surface-sunken)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: iconColor || 'var(--text-secondary)' }}>
          <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 22, lineHeight: 1 }}>{icon}</span>
        </span>
      ) : null)}
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: '600 15px/20px var(--font-sans)', color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</div>
        {subtitle ? <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{subtitle}</div> : null}
      </span>
      {trailing}
      {chevron ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 22, color: 'var(--wls-gray-400)' }}>chevron_right</span> : null}
    </div>
  );
}
