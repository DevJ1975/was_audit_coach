Empty state — copy stays encouraging, never blaming.

```jsx
<EmptyState icon="task_alt" title="All caught up" message="No open findings on your sites. Nice work keeping things tight." action={<Button variant="secondary">Schedule next audit</Button>} />
```
