/**
 * Labelled text input (single or multiline) with helper and error states.
 */
export interface TextFieldProps {
  label?: string;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  /** grey helper line under the field */
  helper?: string;
  /** red error line; also recolors the border */
  error?: string;
  /** Material Symbols icon shown at left */
  icon?: string;
  multiline?: boolean;
  rows?: number;
  disabled?: boolean;
  /** RN-style callback with the raw string */
  onChangeText?: (text: string) => void;
  onChange?: (e: any) => void;
  style?: React.CSSProperties;
}
export declare function TextField(props: TextFieldProps): JSX.Element;
