One-tap action button; use `primary` for the single main action on a screen, `secondary`/`ghost` for everything else.

```jsx
<Button icon="play_arrow" onPress={start}>Start audit</Button>
<Button variant="secondary" size="sm">View report</Button>
```

Variants: primary, secondary, ghost, danger. Sizes sm 36 / md 44 / lg 52 (md+ meets the 44px touch target). `icon` takes a Material Symbols name.
