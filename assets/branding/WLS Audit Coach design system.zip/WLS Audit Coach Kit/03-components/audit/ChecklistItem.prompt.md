The core audit-taking unit. Fail selection outlines the card in red.

```jsx
<ChecklistItem number={3} question="Fire extinguishers mounted, tagged, and inspected" hint="Check the monthly tag on each unit." value="pass" onChange={setV} />
```
