Finding row in lists. Severity = left rail color (critical red / major amber / minor gray).

```jsx
<FindingCard id="F-1042" severity="critical" title="Guard rail bolt missing on mezzanine" site="Plant 4 — Zone B" assignee="D. Okafor" due="Due Fri, Jul 18" overdue />
```
