/**
 * Zero-state block with encouraging coach copy.
 */
export interface EmptyStateProps {
  /** Material Symbols name */
  icon?: string;
  title: string;
  message?: string;
  /** usually a <Button> */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
