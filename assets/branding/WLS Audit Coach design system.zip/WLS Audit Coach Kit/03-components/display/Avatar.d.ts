/**
 * User avatar — initials on a deterministic brand hue, or an image.
 */
export interface AvatarProps {
  /** full name; initials derived */
  name?: string;
  /** image URL (overrides initials) */
  src?: string;
  /** px, default 40 */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Avatar(props: AvatarProps): JSX.Element;
