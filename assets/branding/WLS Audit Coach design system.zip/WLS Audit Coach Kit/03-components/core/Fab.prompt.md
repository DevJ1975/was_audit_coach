Floating action button, bottom-right, 16px from edges, above the BottomNav.

```jsx
<Fab icon="add_task" label="New audit" extended onPress={create} />
```
