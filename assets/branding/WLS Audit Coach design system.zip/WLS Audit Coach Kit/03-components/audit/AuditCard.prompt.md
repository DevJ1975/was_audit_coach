Audit list card. Give `score` for completed audits, `progress`+`status` otherwise.

```jsx
<AuditCard title="Weekly safety walkthrough" site="Plant 4" date="Today" status="in-progress" progress={62} />
<AuditCard title="Fire safety quarterly" site="Warehouse 2" date="Jul 8" score={94} findings={1} />
```
