The signature Audit Coach moment: a short, positive nudge tied to data. Never scolding.

```jsx
<CoachTip actionLabel="See the 2-min refresher" onAction={open}>Ladder findings dropped 40% since May. One habit to lock in: three points of contact, every time.</CoachTip>
```
