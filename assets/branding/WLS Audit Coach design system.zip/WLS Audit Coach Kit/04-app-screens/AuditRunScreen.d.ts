/**
 * Checklist-taking screen with pass/fail/NA responses (phone).
 */
export interface AuditRunScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function AuditRunScreen(props: AuditRunScreenProps): JSX.Element;
