import React from 'react';

/** Coaching callout — encouraging guidance tied to audit results. */
export function CoachTip({ title = 'Coach tip', children, actionLabel, onAction, compact = false, style }) {
  return (
    <div style={{
      display: 'flex', gap: 12, padding: compact ? '12px 14px' : 16,
      background: 'linear-gradient(135deg, var(--color-primary-subtle), transparent 70%), var(--surface-card)',
      border: '1px solid var(--wls-red-100)', borderRadius: 'var(--radius-lg)', alignItems: 'flex-start', ...style,
    }}>
      <span style={{ width: 34, height: 34, flex: 'none', borderRadius: '50%', background: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 19, color: '#fff', fontVariationSettings: "'FILL' 1" }}>school</span>
      </span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: 'var(--type-label)', color: 'var(--text-brand)', marginBottom: 3 }}>{title}</div>
        <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-secondary)', lineHeight: '19px' }}>{children}</div>
        {actionLabel ? <button onClick={onAction} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, border: 'none', background: 'transparent', padding: 0, marginTop: 8, color: 'var(--text-brand)', font: 'var(--type-label)', cursor: 'pointer' }}>{actionLabel}<span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 16 }}>arrow_forward</span></button> : null}
      </span>
    </div>
  );
}
