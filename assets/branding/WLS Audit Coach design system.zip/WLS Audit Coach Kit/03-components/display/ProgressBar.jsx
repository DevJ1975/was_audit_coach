import React from 'react';

/** Linear progress. value 0–100; color auto-follows score bands when scored. */
export function ProgressBar({ value = 0, scored = false, color, height = 8, label, style }) {
  const band = value >= 90 ? 'var(--score-pass)' : value >= 70 ? 'var(--score-fair)' : 'var(--score-fail)';
  const fill = color || (scored ? band : 'var(--color-primary)');
  return (
    <div style={style}>
      {label ? <div style={{ display: 'flex', justifyContent: 'space-between', font: 'var(--type-caption)', color: 'var(--text-muted)', marginBottom: 5 }}><span>{label}</span><span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{Math.round(value)}%</span></div> : null}
      <div style={{ height, borderRadius: 'var(--radius-full)', background: 'var(--score-track)', overflow: 'hidden' }}>
        <div style={{ width: Math.max(0, Math.min(100, value)) + '%', height: '100%', borderRadius: 'var(--radius-full)', background: fill, transition: 'width var(--duration-slow) var(--ease-standard)' }}></div>
      </div>
    </div>
  );
}
