Bottom snackbar, auto-dismiss ~4s. Position it yourself (absolute, above BottomNav).

```jsx
<Toast kind="success" message="Audit submitted — nice work." actionLabel="View" onAction={open} />
```
