Dropdown for site, template, assignee pickers.

```jsx
<Select label="Site" options={['Plant 4 — Dayton', 'Warehouse 2']} defaultValue="Plant 4 — Dayton" />
```
