/**
 * Primary action button for Audit Coach. Brand red for the one main action per screen.
 */
export interface ButtonProps {
  /** primary (brand red, one per screen) | secondary (outlined) | ghost (text) | danger */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** sm 36px | md 44px (default, min touch target) | lg 52px */
  size?: 'sm' | 'md' | 'lg';
  /** Material Symbols icon name, rendered before the label */
  icon?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  onPress?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
