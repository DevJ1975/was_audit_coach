/**
 * Persistent contextual callout (offline, overdue, sync).
 */
export interface BannerProps {
  kind?: 'info' | 'success' | 'warning' | 'danger';
  title?: string;
  children?: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  /** shows an X */
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export declare function Banner(props: BannerProps): JSX.Element;
