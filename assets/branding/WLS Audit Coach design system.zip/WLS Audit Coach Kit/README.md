# WLS Audit Coach — UI/UX Material Pack & Branding Kit

Everything needed to design and build Audit Coach on brand.

## What's inside

**00-brand-guide.md** — the full guide: voice & copy rules, visual foundations, color/type/spacing systems, iconography rules, logo usage.

**01-brand/** — the retraced logo set (vector masters + PNG exports):
- `logo/wls-globe.svg` — master globe mark
- `logo/wls-lockup-horizontal.svg` — original Workplace Learning System lockup
- `logo/audit-coach-lockup-h.svg` / `audit-coach-lockup-stacked.svg` — product lockups
- `logo/app-icon-light.svg` / `app-icon-dark.svg` — SaaS app icon (+ PNG at 1024/512/192 in `logo/png/`)
- `logo/wls-glyph-*.svg` — flat mono glyph for favicons / small sizes (seams knock out)
- `original-logo.jpg` — the source logo supplied by WLS

## Using it

**Web:** link `02-tokens/styles.css` and use the `var(--*)` tokens.

**React Native:** import `02-tokens/react-native-theme.js` — exports `lightTheme` / `darkTheme`, `spacing`, `radius`, `type`, and `toPaperTheme()` for React Native Paper (MD3). Load fonts via `@expo-google-fonts/source-sans-3` and `@expo-google-fonts/ibm-plex-mono`; icons are Material Symbols Rounded.

**Components (03-components/):** 26 reference implementations (React JSX, inline-styled with the tokens), each with a `.d.ts` props contract and a `.prompt.md` usage note. Port to RN by swapping div/button for View/Pressable — all values are token-based.

**App screens (04-app-screens/):** the 7 Audit Coach screens plus `index.html`, an interactive phone demo (open in any browser — needs internet for React/Babel/fonts CDN).

**Component previews:** open any `*.card.html` in a browser to see rendered component states.
