/**
 * Pill label for audit/finding lifecycle states.
 */
export interface StatusBadgeProps {
  status: 'pass' | 'fail' | 'na' | 'open' | 'in-progress' | 'resolved' | 'overdue' | 'draft' | 'scheduled';
  /** override the default text */
  label?: string;
  style?: React.CSSProperties;
}
export declare function StatusBadge(props: StatusBadgeProps): JSX.Element;
