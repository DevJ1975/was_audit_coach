/**
 * Audit Coach home dashboard (phone).
 */
export interface DashboardScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function DashboardScreen(props: DashboardScreenProps): JSX.Element;
