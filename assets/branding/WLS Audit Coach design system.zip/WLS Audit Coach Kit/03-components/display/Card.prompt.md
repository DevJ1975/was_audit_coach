Base surface for dashboard stats, audit summaries, settings groups.

```jsx
<Card onPress={open}>…</Card>
<Card variant="filled" padding={12}>…</Card>
```
