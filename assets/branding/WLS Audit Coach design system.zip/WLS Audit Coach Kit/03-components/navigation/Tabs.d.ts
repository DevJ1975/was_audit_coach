/**
 * Underline tabs for switching sections within one screen.
 */
export interface TabsProps {
  tabs: Array<string | { value: string; label: string; count?: number }>;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
