Inline callout that stays until resolved/dismissed.

```jsx
<Banner kind="warning" title="2 corrective actions due Friday" actionLabel="Review now" onAction={go}>Zone B guard rail and forklift horn.</Banner>
```
