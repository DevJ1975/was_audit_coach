import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { IconButton } from '../../03-components/core/IconButton.jsx';
import { ProgressBar } from '../../03-components/display/ProgressBar.jsx';
import { ChecklistItem } from '../../03-components/audit/ChecklistItem.jsx';
import { Button } from '../../03-components/core/Button.jsx';
import { CoachTip } from '../../03-components/audit/CoachTip.jsx';

/** Conducting an audit: section progress + checklist questions + submit. */
export function AuditRunScreen({ onNavigate }) {
  const [answers, setAnswers] = React.useState({ 1: 'pass', 2: 'pass', 3: 'fail' });
  const total = 6;
  const done = Object.values(answers).filter(Boolean).length;
  const set = (n) => (v) => setAnswers(a => ({ ...a, [n]: v }));
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--surface-page)' }}>
      <div style={{ background: 'var(--surface-card)', borderBottom: '1px solid var(--border-default)' }}>
        <AppBar title="Weekly safety walkthrough" subtitle="Plant 4 — Zone B" transparent onBack={() => onNavigate && onNavigate('audits')} actions={<IconButton icon="more_vert" label="More" />} />
        <div style={{ padding: '0 16px 12px' }}>
          <ProgressBar value={done / total * 100} height={6} label={done + ' of ' + total + ' answered'} />
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ font: 'var(--type-overline)', letterSpacing: 'var(--tracking-overline)', textTransform: 'uppercase', color: 'var(--text-muted)', margin: '2px 2px 0' }}>Section 2 of 4 — Fire safety</div>
        <ChecklistItem number={1} question="Fire extinguishers mounted, tagged, and inspected" hint="Check the monthly tag on each unit." value={answers[1]} onChange={set(1)} />
        <ChecklistItem number={2} question="Sprinkler heads have 18 in clearance" value={answers[2]} onChange={set(2)} />
        <ChecklistItem number={3} question="Emergency exits clear of obstructions" value={answers[3]} onChange={set(3)} photoCount={2} noteCount={1} />
        {answers[3] === 'fail' ? <CoachTip title="Nice catch" compact>Snap a photo and assign it now — findings logged on the spot get fixed 2× faster.</CoachTip> : null}
        <ChecklistItem number={4} question="Fire doors close and latch fully" value={answers[4]} onChange={set(4)} />
        <ChecklistItem number={5} question="Flammables stored in rated cabinets" value={answers[5]} onChange={set(5)} />
        <ChecklistItem number={6} question="Evacuation map posted and current" value={answers[6]} onChange={set(6)} />
      </div>
      <div style={{ padding: '12px 16px', background: 'var(--surface-card)', borderTop: '1px solid var(--border-default)', display: 'flex', gap: 10 }}>
        <Button variant="secondary" style={{ flex: 1 }}>Save draft</Button>
        <Button style={{ flex: 2 }} icon="check" onPress={() => onNavigate && onNavigate('submitted')}>Submit section</Button>
      </div>
    </div>
  );
}
