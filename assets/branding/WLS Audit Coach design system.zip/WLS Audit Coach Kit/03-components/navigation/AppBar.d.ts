/**
 * Top app bar with optional back arrow, subtitle, and action icons.
 */
export interface AppBarProps {
  title: string;
  subtitle?: string;
  /** shows the back arrow */
  onBack?: () => void;
  /** right-side nodes, usually IconButtons */
  actions?: React.ReactNode;
  /** headline-size title for root screens */
  large?: boolean;
  transparent?: boolean;
  style?: React.CSSProperties;
}
export declare function AppBar(props: AppBarProps): JSX.Element;
