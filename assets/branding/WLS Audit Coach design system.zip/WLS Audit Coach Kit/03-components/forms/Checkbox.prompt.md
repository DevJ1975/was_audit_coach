Checkbox for multi-select lists and consent rows.

```jsx
<Checkbox label="Include photos in report" defaultChecked />
```
