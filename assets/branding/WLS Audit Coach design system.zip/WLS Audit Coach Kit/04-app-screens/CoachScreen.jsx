import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { Card } from '../../03-components/display/Card.jsx';
import { CoachTip } from '../../03-components/audit/CoachTip.jsx';
import { ListItem } from '../../03-components/display/ListItem.jsx';
import { ProgressBar } from '../../03-components/display/ProgressBar.jsx';
import { StatusBadge } from '../../03-components/audit/StatusBadge.jsx';

/** Coaching & training content tied to audit results. */
export function CoachScreen() {
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <AppBar large title="Coach" subtitle="Training picked from your audit data" transparent />
      <div style={{ padding: '0 16px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <CoachTip title="This week's focus" actionLabel="Start the 2-min refresher">Lockout / tagout scored 68% in July — the lowest category on your site. A quick crew huddle usually moves this 10+ points.</CoachTip>
        <div>
          <div style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)', margin: '4px 2px 8px' }}>Recommended for your crew</div>
          <Card padding={0} style={{ overflow: 'hidden' }}>
            <ListItem icon="lock" iconColor="var(--text-brand)" title="Lockout / tagout essentials" subtitle="6 min · refresher" trailing={<StatusBadge status="scheduled" label="Assigned" />} chevron onPress={() => {}} />
            <ListItem icon="forklift" title="Forklift daily inspection" subtitle="4 min · micro-lesson" chevron onPress={() => {}} />
            <ListItem icon="stairs" title="Ladder: 3 points of contact" subtitle="2 min · habit builder" divider={false} chevron onPress={() => {}} />
          </Card>
        </div>
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
            <span style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)' }}>Crew completion</span>
            <span style={{ font: 'var(--type-caption)', color: 'var(--text-muted)' }}>July</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <ProgressBar value={100} color="var(--score-pass)" label="PPE refresher" />
            <ProgressBar value={75} label="Fire extinguisher use" />
            <ProgressBar value={40} label="Lockout / tagout essentials" />
          </div>
        </Card>
      </div>
    </div>
  );
}
