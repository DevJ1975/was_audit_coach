import React from 'react';

/** Bottom navigation. items: [{key, icon, label, badge?}]. */
export function BottomNav({ items = [], value, onChange, style }) {
  return (
    <div style={{ display: 'flex', background: 'var(--surface-card)', borderTop: '1px solid var(--border-default)', paddingBottom: 6, paddingTop: 6, ...style }}>
      {items.map(it => {
        const on = value === it.key;
        return (
          <button key={it.key} onClick={() => onChange && onChange(it.key)} style={{ flex: 1, border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, padding: '4px 0', minHeight: 52 }}>
            <span style={{ position: 'relative', width: 56, height: 30, borderRadius: 'var(--radius-full)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: on ? 'var(--color-primary-subtle)' : 'transparent', transition: 'background var(--duration-base) var(--ease-standard)' }}>
              <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 23, lineHeight: 1, color: on ? 'var(--text-brand)' : 'var(--text-muted)', fontVariationSettings: on ? "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24" : "'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24" }}>{it.icon}</span>
              {it.badge ? <span style={{ position: 'absolute', top: -2, right: 8, minWidth: 16, height: 16, padding: '0 4px', background: 'var(--wls-red-500)', color: '#fff', borderRadius: 999, font: '700 10px/16px var(--font-sans)', textAlign: 'center', border: '2px solid var(--surface-card)', boxSizing: 'content-box' }}>{it.badge}</span> : null}
            </span>
            <span style={{ font: on ? '700 11px/13px var(--font-sans)' : '600 11px/13px var(--font-sans)', color: on ? 'var(--text-brand)' : 'var(--text-muted)' }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}
