Initials avatar for auditors and assignees.

```jsx
<Avatar name="Maria Rivera" />
<Avatar name="Dan Okafor" size={28} />
```
