List row, 60px min height.

```jsx
<ListItem icon="factory" title="Plant 4 — Dayton" subtitle="12 audits this month" chevron onPress={open} />
```
