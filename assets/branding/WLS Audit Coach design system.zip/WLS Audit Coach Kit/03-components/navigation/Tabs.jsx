import React from 'react';

/** Underlined text tabs for sections within a screen. tabs: strings or {value,label,count?}. */
export function Tabs({ tabs = [], value, defaultValue, onChange, style }) {
  const opts = tabs.map(t => typeof t === 'string' ? { value: t, label: t } : t);
  const [internal, setInternal] = React.useState(defaultValue ?? (opts[0] && opts[0].value));
  const current = value !== undefined ? value : internal;
  return (
    <div style={{ display: 'flex', gap: 4, borderBottom: '1.5px solid var(--border-default)', overflowX: 'auto', ...style }}>
      {opts.map(t => {
        const on = current === t.value;
        return (
          <button key={t.value}
            onClick={() => { if (value === undefined) setInternal(t.value); onChange && onChange(t.value); }}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6, padding: '12px 14px', border: 'none', background: 'transparent',
              font: on ? '700 15px/20px var(--font-sans)' : '600 15px/20px var(--font-sans)',
              color: on ? 'var(--text-brand)' : 'var(--text-muted)', cursor: 'pointer', whiteSpace: 'nowrap',
              boxShadow: on ? 'inset 0 -2.5px 0 var(--color-primary)' : 'none', marginBottom: -1.5,
              transition: 'color var(--duration-fast) var(--ease-standard)',
            }}>
            {t.label}
            {t.count !== undefined ? <span style={{ font: '700 11px/18px var(--font-sans)', background: on ? 'var(--color-primary-subtle)' : 'var(--surface-sunken)', color: on ? 'var(--text-brand)' : 'var(--text-muted)', borderRadius: 999, padding: '0 7px' }}>{t.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
