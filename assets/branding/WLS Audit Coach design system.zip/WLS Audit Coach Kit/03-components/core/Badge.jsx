import React from 'react';

/** Numeric or dot badge, anchored to a child or standalone. */
export function Badge({ count, dot = false, max = 99, children, style }) {
  const label = count > max ? max + '+' : count;
  const badge = (
    <span style={{
      minWidth: dot ? 10 : 18, height: dot ? 10 : 18, padding: dot ? 0 : '0 5px',
      background: 'var(--wls-red-500)', color: '#fff', borderRadius: 'var(--radius-full)',
      font: '700 11px/18px var(--font-sans)', textAlign: 'center', display: 'inline-block',
      border: '2px solid var(--surface-card)', boxSizing: 'content-box', ...(!children ? style : {}),
    }}>{dot ? '' : label}</span>
  );
  if (!children) return badge;
  return (
    <span style={{ position: 'relative', display: 'inline-flex', ...style }}>
      {children}
      <span style={{ position: 'absolute', top: -4, right: -6 }}>{badge}</span>
    </span>
  );
}
