// WLS Audit Coach — React Native theme object
// Mirrors tokens/*.css. Import into your RN app or map into React Native Paper (MD3).

export const palette = {
  red50: '#FCEDEE', red100: '#F8D4D8', red200: '#F0A9B0', red300: '#E67D88', red400: '#DB4F5E',
  red500: '#CE1F30', red600: '#AE1123', red700: '#8E0E1A', red800: '#6E0B15', red900: '#4F080F',
  gray0: '#FFFFFF', gray25: '#FCFCFD', gray50: '#F7F7F8', gray100: '#F0F1F3', gray200: '#E4E6E9',
  gray300: '#D3D6DA', gray400: '#ACB0B5', gray500: '#83878D', gray600: '#62666C', gray700: '#4A4D53',
  gray800: '#313439', gray900: '#1E2023', gray950: '#131417',
  green500: '#1D8A50', green700: '#156A3D', green100: '#DCF3E6',
  amber500: '#B45309', amber600: '#92450A', amber100: '#FBEED7',
  blue500: '#2D6CB5', blue700: '#235489', blue100: '#E5EFF9',
};

export const lightTheme = {
  dark: false,
  colors: {
    primary: palette.red500, primaryHover: palette.red600, primaryPressed: palette.red700,
    primarySubtle: palette.red50, onPrimary: '#FFFFFF',
    surfacePage: palette.gray50, surfaceCard: palette.gray0, surfaceRaised: palette.gray0,
    surfaceSunken: palette.gray100, surfaceInverse: palette.gray900, overlay: 'rgba(19,20,23,0.52)',
    textPrimary: palette.gray900, textSecondary: palette.gray600, textMuted: palette.gray500,
    textInverse: '#FFFFFF', textBrand: palette.red500, textLink: palette.red600,
    borderDefault: palette.gray200, borderStrong: palette.gray300, borderFocus: palette.red500,
    success: palette.green500, successText: palette.green700, successBg: palette.green100,
    warning: palette.amber500, warningText: palette.amber600, warningBg: palette.amber100,
    danger: palette.red500, dangerText: palette.red600, dangerBg: palette.red50,
    info: palette.blue500, infoText: palette.blue700, infoBg: palette.blue100,
    scorePass: palette.green500, scoreFair: '#DD9210', scoreFail: palette.red500,
    scoreNa: palette.gray400, scoreTrack: palette.gray200,
  },
};

export const darkTheme = {
  dark: true,
  colors: {
    ...lightTheme.colors,
    primary: '#E4576B', primaryHover: '#EB7284', primaryPressed: '#DB4F5E',
    primarySubtle: 'rgba(228,87,107,0.14)',
    surfacePage: palette.gray950, surfaceCard: palette.gray900, surfaceRaised: '#26282C',
    surfaceSunken: '#0D0E10', surfaceInverse: palette.gray0, overlay: 'rgba(0,0,0,0.6)',
    textPrimary: '#F2F3F4', textSecondary: palette.gray400, textMuted: palette.gray500,
    textInverse: palette.gray900, textBrand: '#E4576B', textLink: '#EB7284',
    borderDefault: '#33363B', borderStrong: palette.gray700, borderFocus: '#E4576B',
    success: '#3DBE7E', successText: '#6BD49E', successBg: 'rgba(61,190,126,0.14)',
    warning: '#E8A317', warningText: '#F0B94A', warningBg: 'rgba(232,163,23,0.14)',
    danger: '#E4576B', dangerText: '#EB7284', dangerBg: 'rgba(228,87,107,0.14)',
    info: '#5B9BDD', infoText: '#83B4E6', infoBg: 'rgba(91,155,221,0.14)',
    scorePass: '#3DBE7E', scoreFair: '#E8A317', scoreFail: '#E4576B',
    scoreNa: palette.gray600, scoreTrack: '#33363B',
  },
};

export const spacing = { s1: 4, s2: 8, s3: 12, s4: 16, s5: 20, s6: 24, s7: 32, s8: 40, s9: 48, s10: 64 };
export const radius = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, full: 999 };
export const hitTarget = 44;

// Font families — load via expo-google-fonts or link the TTFs:
// @expo-google-fonts/source-sans-3 (400/500/600/700), @expo-google-fonts/ibm-plex-mono (400/500/600)
export const type = {
  sans: 'SourceSans3', mono: 'IBMPlexMono',
  display:  { fontFamily: 'SourceSans3-Bold', fontSize: 34, lineHeight: 40 },
  headline: { fontFamily: 'SourceSans3-Bold', fontSize: 26, lineHeight: 32 },
  title:    { fontFamily: 'SourceSans3-SemiBold', fontSize: 20, lineHeight: 26 },
  titleSm:  { fontFamily: 'SourceSans3-SemiBold', fontSize: 17, lineHeight: 22 },
  bodyLg:   { fontFamily: 'SourceSans3-Regular', fontSize: 17, lineHeight: 24 },
  body:     { fontFamily: 'SourceSans3-Regular', fontSize: 15, lineHeight: 22 },
  bodySm:   { fontFamily: 'SourceSans3-Regular', fontSize: 13, lineHeight: 18 },
  label:    { fontFamily: 'SourceSans3-SemiBold', fontSize: 13, lineHeight: 16, letterSpacing: 0.13 },
  caption:  { fontFamily: 'SourceSans3-Regular', fontSize: 12, lineHeight: 16 },
  overline: { fontFamily: 'SourceSans3-Bold', fontSize: 11, lineHeight: 14, letterSpacing: 0.88, textTransform: 'uppercase' },
  data:     { fontFamily: 'IBMPlexMono-Medium', fontSize: 15, lineHeight: 20 },
  dataLg:   { fontFamily: 'IBMPlexMono-SemiBold', fontSize: 28, lineHeight: 32 },
};

// React Native Paper (MD3) adapter
export function toPaperTheme(base = lightTheme) {
  const c = base.colors;
  return {
    dark: base.dark,
    roundness: radius.md,
    colors: {
      primary: c.primary, onPrimary: c.onPrimary,
      primaryContainer: c.primarySubtle, onPrimaryContainer: c.textBrand,
      secondary: c.textSecondary, onSecondary: c.textInverse,
      background: c.surfacePage, onBackground: c.textPrimary,
      surface: c.surfaceCard, onSurface: c.textPrimary,
      surfaceVariant: c.surfaceSunken, onSurfaceVariant: c.textSecondary,
      outline: c.borderStrong, outlineVariant: c.borderDefault,
      error: c.danger, onError: '#FFFFFF', errorContainer: c.dangerBg, onErrorContainer: c.dangerText,
      inverseSurface: c.surfaceInverse, inverseOnSurface: c.textInverse,
      elevation: { level0: 'transparent', level1: c.surfaceCard, level2: c.surfaceCard, level3: c.surfaceRaised, level4: c.surfaceRaised, level5: c.surfaceRaised },
    },
  };
}
