Blocking confirm. Keep to one decision, two actions.

```jsx
<Dialog icon="delete" destructive title="Delete this draft?" actions={<><Button variant="ghost">Keep it</Button><Button variant="danger">Delete</Button></>}>You can’t undo this.</Dialog>
```
