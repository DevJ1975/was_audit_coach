Top bar. Root screens: `large` + no back. Detail screens: back arrow + title.

```jsx
<AppBar large title="Dashboard" actions={<IconButton icon="notifications" />} />
<AppBar title="Fire safety audit" subtitle="Plant 4 — Dayton" onBack={pop} />
```
