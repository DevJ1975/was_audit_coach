/**
 * Confirmation / decision modal.
 */
export interface DialogProps {
  open?: boolean;
  /** Material Symbols name shown in a tinted circle */
  icon?: string;
  title: string;
  children?: React.ReactNode;
  /** usually two Buttons: ghost + primary/danger */
  actions?: React.ReactNode;
  /** tints the icon circle red */
  destructive?: boolean;
  /** backdrop click */
  onClose?: () => void;
  style?: React.CSSProperties;
}
export declare function Dialog(props: DialogProps): JSX.Element;
