import React from 'react';

/** Vertical radio group. options: [{value,label,description?}] or strings. */
export function RadioGroup({ options = [], value, defaultValue, disabled = false, onChange, style }) {
  const [internal, setInternal] = React.useState(defaultValue);
  const current = value !== undefined ? value : internal;
  const opts = options.map(o => typeof o === 'string' ? { value: o, label: o } : o);
  return (
    <div role="radiogroup" style={{ display: 'flex', flexDirection: 'column', gap: 14, ...style }}>
      {opts.map(o => {
        const on = current === o.value;
        return (
          <div key={o.value} role="radio" aria-checked={on}
            onClick={() => { if (disabled) return; if (value === undefined) setInternal(o.value); onChange && onChange(o.value); }}
            style={{ display: 'flex', gap: 12, alignItems: o.description ? 'flex-start' : 'center', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1 }}>
            <span style={{
              width: 22, height: 22, flex: 'none', borderRadius: '50%', boxSizing: 'border-box',
              border: on ? '7px solid var(--color-primary)' : '1.5px solid var(--border-strong)',
              background: 'var(--surface-card)', transition: 'border var(--duration-fast) var(--ease-standard)', marginTop: o.description ? 1 : 0,
            }}></span>
            <span>
              <div style={{ font: 'var(--type-body)', color: 'var(--text-primary)' }}>{o.label}</div>
              {o.description ? <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)' }}>{o.description}</div> : null}
            </span>
          </div>
        );
      })}
    </div>
  );
}
