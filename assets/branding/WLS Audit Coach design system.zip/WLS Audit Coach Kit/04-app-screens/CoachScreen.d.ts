/**
 * Coaching / training screen (phone).
 */
export interface CoachScreenProps {
  /** navigate callback: (route: string) => void */
  onNavigate?: (route: string) => void;
}
export declare function CoachScreen(props: CoachScreenProps): JSX.Element;
