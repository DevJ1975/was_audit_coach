import React from 'react';

/** Single-line or multiline text input with label, helper, error. */
export function TextField({ label, value, defaultValue, placeholder, helper, error, icon, multiline = false, rows = 3, disabled = false, onChange, onChangeText, style }) {
  const [focus, setFocus] = React.useState(false);
  const id = React.useId();
  const border = error ? '1.5px solid var(--status-danger)' : focus ? '1.5px solid var(--border-focus)' : '1.5px solid var(--border-strong)';
  const common = {
    width: '100%', boxSizing: 'border-box', font: 'var(--type-body)', fontFamily: 'var(--font-sans)',
    color: 'var(--text-primary)', background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
    border, borderRadius: 'var(--radius-md)', outline: 'none',
    boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
    transition: 'box-shadow var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)',
    padding: multiline ? '12px 14px' : icon ? '0 14px 0 42px' : '0 14px',
    height: multiline ? undefined : 48,
  };
  const handle = (e) => { onChange && onChange(e); onChangeText && onChangeText(e.target.value); };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label ? <label htmlFor={id} style={{ font: 'var(--type-label)', color: 'var(--text-primary)' }}>{label}</label> : null}
      <div style={{ position: 'relative' }}>
        {icon && !multiline ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 20, position: 'absolute', left: 13, top: 14, color: 'var(--text-muted)', pointerEvents: 'none' }}>{icon}</span> : null}
        {multiline
          ? <textarea id={id} rows={rows} value={value} defaultValue={defaultValue} placeholder={placeholder} disabled={disabled} onChange={handle} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} style={{ ...common, resize: 'vertical' }} />
          : <input id={id} value={value} defaultValue={defaultValue} placeholder={placeholder} disabled={disabled} onChange={handle} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} style={common} />}
      </div>
      {(error || helper) ? <div style={{ font: 'var(--type-caption)', color: error ? 'var(--status-danger-text)' : 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 4 }}>
        {error ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 14 }}>error</span> : null}{error || helper}
      </div> : null}
    </div>
  );
}
