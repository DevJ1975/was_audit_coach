import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { IconButton } from '../../03-components/core/IconButton.jsx';
import { Tabs } from '../../03-components/navigation/Tabs.jsx';
import { FindingCard } from '../../03-components/audit/FindingCard.jsx';
import { EmptyState } from '../../03-components/display/EmptyState.jsx';
import { Button } from '../../03-components/core/Button.jsx';

/** Findings & corrective actions, tabbed by state. */
export function FindingsScreen({ onNavigate }) {
  const [tab, setTab] = React.useState('open');
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <AppBar large title="Findings" transparent actions={<IconButton icon="ios_share" label="Export" />} />
      <div style={{ background: 'var(--surface-card)' }}>
        <Tabs tabs={[{ value: 'open', label: 'Open', count: 3 }, { value: 'progress', label: 'In progress', count: 2 }, { value: 'resolved', label: 'Resolved' }]} value={tab} onChange={setTab} style={{ padding: '0 8px' }} />
      </div>
      <div style={{ padding: '14px 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {tab === 'open' ? <>
          <FindingCard id="F-1042" severity="critical" title="Guard rail bolt missing on mezzanine" site="Plant 4 — Zone B" assignee="D. Okafor" due="Due today" overdue onPress={() => {}} />
          <FindingCard id="F-1044" severity="major" title="Forklift horn intermittent on unit 7" site="Plant 4 — Dock 2" assignee="Unassigned" due="Due today" onPress={() => {}} />
          <FindingCard id="F-1038" severity="minor" title="Aisle tape worn near dock 3" site="Warehouse 2" assignee="P. Shah" due="Due Jul 25" onPress={() => {}} />
        </> : null}
        {tab === 'progress' ? <>
          <FindingCard id="F-1035" severity="major" title="Eyewash station flow below spec" site="Line 3" assignee="M. Chen" due="Due Jul 16" status="in-progress" onPress={() => {}} />
          <FindingCard id="F-1031" severity="minor" title="Label missing on solvent drum" site="Warehouse 2" assignee="P. Shah" due="Due Jul 15" status="in-progress" onPress={() => {}} />
        </> : null}
        {tab === 'resolved' ? (
          <EmptyState icon="task_alt" title="Resolved findings archive here" message="Close out an open finding and it lands in this tab with its fix photo and sign-off." action={<Button variant="secondary" size="sm" onPress={() => setTab('open')}>Go to open</Button>} />
        ) : null}
      </div>
    </div>
  );
}
