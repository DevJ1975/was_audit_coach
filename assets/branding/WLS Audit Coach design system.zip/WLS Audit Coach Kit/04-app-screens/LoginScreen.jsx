import React from 'react';
import { Button } from '../../03-components/core/Button.jsx';
import { TextField } from '../../03-components/forms/TextField.jsx';

/** Sign-in screen with stacked product lockup. */
export function LoginScreen({ onNavigate }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface-card)', padding: '0 24px', boxSizing: 'border-box' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
        <img src="../../01-brand/logo/wls-globe.svg" alt="WLS" style={{ width: 84, marginBottom: 14 }} />
        <div style={{ font: 'var(--type-headline)', color: 'var(--text-primary)' }}>Audit Coach</div>
        <div style={{ font: 'var(--type-overline)', letterSpacing: 'var(--tracking-overline)', textTransform: 'uppercase', color: 'var(--text-muted)' }}>Workplace Learning System</div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingBottom: 28 }}>
        <TextField label="Work email" icon="mail" placeholder="you@company.com" defaultValue="m.rivera@trainovations.com" />
        <TextField label="Password" icon="lock" placeholder="••••••••" defaultValue="••••••••" />
        <Button size="lg" fullWidth onPress={() => onNavigate && onNavigate('home')}>Sign in</Button>
        <Button variant="ghost" fullWidth>Use single sign-on</Button>
        <div style={{ font: 'var(--type-caption)', color: 'var(--text-muted)', textAlign: 'center' }}>Trouble signing in? Ask your site admin.</div>
      </div>
    </div>
  );
}
