import React from 'react';

/** Filter / choice chip. */
export function Chip({ selected = false, icon, onPress, onClick, children, style }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onPress || onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, height: 34, padding: '0 14px',
        font: 'var(--type-label)', letterSpacing: 'var(--tracking-label)',
        color: selected ? 'var(--color-on-primary)' : 'var(--text-secondary)',
        background: selected ? 'var(--wls-gray-900)' : hover ? 'var(--surface-sunken)' : 'var(--surface-card)',
        border: selected ? '1.5px solid var(--wls-gray-900)' : '1.5px solid var(--border-strong)',
        borderRadius: 'var(--radius-full)', cursor: 'pointer', whiteSpace: 'nowrap',
        transition: 'all var(--duration-fast) var(--ease-standard)', ...style,
      }}
    >
      {selected && !icon ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 16, lineHeight: 1 }}>check</span> : null}
      {icon ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 16, lineHeight: 1 }}>{icon}</span> : null}
      {children}
    </button>
  );
}
