import React from 'react';

/** Floating action button — one per screen, brand red. extended shows a label. */
export function Fab({ icon = 'add', label, extended = false, onPress, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onPress || onClick} aria-label={label || icon}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        height: 56, minWidth: 56, padding: extended ? '0 20px' : 0,
        background: hover ? 'var(--color-primary-hover)' : 'var(--color-primary)', color: 'var(--color-on-primary)',
        border: 'none', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--elevation-fab)',
        font: '600 15px/20px var(--font-sans)', cursor: 'pointer',
        transition: 'background var(--duration-fast) var(--ease-standard)', ...style,
      }}
    >
      <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 24, lineHeight: 1, fontVariationSettings: "'FILL' 0, 'wght' 500, 'GRAD' 0, 'opsz' 24" }}>{icon}</span>
      {extended && label}
    </button>
  );
}
