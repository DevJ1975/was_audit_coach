import React from 'react';
import { AppBar } from '../../03-components/navigation/AppBar.jsx';
import { IconButton } from '../../03-components/core/IconButton.jsx';
import { Badge } from '../../03-components/core/Badge.jsx';
import { Card } from '../../03-components/display/Card.jsx';
import { ScoreRing } from '../../03-components/audit/ScoreRing.jsx';
import { CoachTip } from '../../03-components/audit/CoachTip.jsx';
import { Banner } from '../../03-components/feedback/Banner.jsx';
import { ListItem } from '../../03-components/display/ListItem.jsx';
import { StatusBadge } from '../../03-components/audit/StatusBadge.jsx';

/** Home dashboard: site score hero, quick stats, coach tip, today's audits. */
export function DashboardScreen({ onNavigate }) {
  const go = (r) => onNavigate && onNavigate(r);
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <AppBar large title="Morning, Maria" subtitle="Friday, July 11" transparent
        actions={<><Badge count={3}><IconButton icon="notifications" label="Alerts" /></Badge><IconButton icon="account_circle" label="Profile" /></>} />
      <div style={{ padding: '4px 16px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Card onPress={() => go('reports')}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <ScoreRing value={92} size={104} label="Site score" />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div>
                <div style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)' }}>Plant 4 — Dayton</div>
                <div style={{ font: 'var(--type-body-sm)', color: 'var(--status-success-text)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 15 }}>trending_up</span>+4 pts vs June
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <div style={{ flex: 1, background: 'var(--surface-sunken)', borderRadius: 10, padding: '8px 10px' }}>
                  <div style={{ font: 'var(--type-data)', color: 'var(--text-primary)' }}>7</div>
                  <div style={{ font: 'var(--type-caption)', color: 'var(--text-muted)' }}>audits due</div>
                </div>
                <div style={{ flex: 1, background: 'var(--surface-sunken)', borderRadius: 10, padding: '8px 10px' }}>
                  <div style={{ font: 'var(--type-data)', color: 'var(--score-fail)' }}>3</div>
                  <div style={{ font: 'var(--type-caption)', color: 'var(--text-muted)' }}>open findings</div>
                </div>
              </div>
            </div>
          </div>
        </Card>
        <Banner kind="warning" title="2 corrective actions due today" actionLabel="Review now" onAction={() => go('findings')}>Zone B guard rail and forklift horn check.</Banner>
        <CoachTip actionLabel="See the 2-min refresher" onAction={() => go('coach')}>Ladder findings dropped 40% since May. One habit to lock in: three points of contact, every time.</CoachTip>
        <div>
          <div style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)', margin: '6px 2px 8px' }}>Today</div>
          <Card padding={0} style={{ overflow: 'hidden' }}>
            <ListItem icon="checklist" iconColor="var(--text-brand)" title="Weekly safety walkthrough" subtitle="Zone A–C · 24 items" trailing={<StatusBadge status="in-progress" />} onPress={() => go('audit')} />
            <ListItem icon="forklift" title="Forklift pre-shift check" subtitle="Dock 2 · 12 items" trailing={<StatusBadge status="scheduled" label="2:00 PM" />} onPress={() => go('audit')} />
            <ListItem icon="cleaning_services" title="Housekeeping — 5S" subtitle="Line 3 · 18 items" divider={false} trailing={<StatusBadge status="scheduled" label="4:30 PM" />} onPress={() => go('audit')} />
          </Card>
        </div>
      </div>
    </div>
  );
}
