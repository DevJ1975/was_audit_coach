import React from 'react';

/** Top app bar. Shows back arrow when onBack given; actions = right-side nodes. */
export function AppBar({ title, subtitle, onBack, actions, large = false, transparent = false, style }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6, minHeight: 56, padding: large ? '14px 8px 12px' : '6px 8px',
      background: transparent ? 'transparent' : 'var(--surface-card)',
      borderBottom: transparent ? 'none' : '1px solid var(--border-default)', boxSizing: 'border-box', ...style,
    }}>
      {onBack ? (
        <button onClick={onBack} aria-label="Back" style={{ width: 44, height: 44, border: 'none', background: 'transparent', borderRadius: '50%', cursor: 'pointer', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 24 }}>arrow_back</span>
        </button>
      ) : <span style={{ width: 10 }}></span>}
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: large ? 'var(--type-headline)' : 'var(--type-title)', color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</div>
        {subtitle ? <div style={{ font: 'var(--type-caption)', color: 'var(--text-muted)' }}>{subtitle}</div> : null}
      </span>
      <span style={{ display: 'flex', alignItems: 'center', gap: 2 }}>{actions}</span>
    </div>
  );
}
