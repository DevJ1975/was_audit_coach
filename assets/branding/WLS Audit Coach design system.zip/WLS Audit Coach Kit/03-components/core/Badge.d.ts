/**
 * Notification count / dot badge.
 */
export interface BadgeProps {
  count?: number;
  /** render as a plain dot */
  dot?: boolean;
  /** cap shown count, default 99 */
  max?: number;
  /** element to anchor to */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
