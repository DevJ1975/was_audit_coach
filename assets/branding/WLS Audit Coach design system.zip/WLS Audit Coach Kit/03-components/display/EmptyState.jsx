import React from 'react';

/** Centered empty/zero state with icon, coach-tone copy, and optional action. */
export function EmptyState({ icon = 'inbox', title, message, action, style }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '40px 24px', gap: 6, ...style }}>
      <span style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--surface-sunken)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
        <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 30, color: 'var(--text-muted)' }}>{icon}</span>
      </span>
      <div style={{ font: 'var(--type-title-sm)', color: 'var(--text-primary)' }}>{title}</div>
      {message ? <div style={{ font: 'var(--type-body)', color: 'var(--text-muted)', maxWidth: 300 }}>{message}</div> : null}
      {action ? <div style={{ marginTop: 12 }}>{action}</div> : null}
    </div>
  );
}
