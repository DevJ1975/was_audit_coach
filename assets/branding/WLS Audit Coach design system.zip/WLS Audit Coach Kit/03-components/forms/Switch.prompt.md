Settings toggle.

```jsx
<Switch label="Offline mode" description="Keep audits on device until you sync." defaultChecked />
```
