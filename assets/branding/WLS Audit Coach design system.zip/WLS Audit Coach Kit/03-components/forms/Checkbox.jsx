import React from 'react';

/** Checkbox with label; supports indeterminate. */
export function Checkbox({ checked, defaultChecked = false, indeterminate = false, label, description, disabled = false, onChange, style }) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const isOn = checked !== undefined ? checked : internal;
  const toggle = () => { if (disabled) return; const v = !isOn; if (checked === undefined) setInternal(v); onChange && onChange(v); };
  return (
    <div onClick={toggle} role="checkbox" aria-checked={isOn} style={{ display: 'flex', gap: 12, alignItems: description ? 'flex-start' : 'center', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1, minHeight: 24, ...style }}>
      <span style={{
        width: 22, height: 22, flex: 'none', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: isOn || indeterminate ? 'var(--color-primary)' : 'var(--surface-card)',
        border: isOn || indeterminate ? '1.5px solid var(--color-primary)' : '1.5px solid var(--border-strong)',
        transition: 'all var(--duration-fast) var(--ease-standard)', marginTop: description ? 1 : 0, boxSizing: 'border-box',
      }}>
        {(isOn || indeterminate) ? <span className="ms" style={{ fontFamily: 'Material Symbols Rounded', fontSize: 16, color: '#fff', fontVariationSettings: "'wght' 700" }}>{indeterminate ? 'remove' : 'check'}</span> : null}
      </span>
      {(label || description) ? <span>
        {label ? <div style={{ font: 'var(--type-body)', color: 'var(--text-primary)' }}>{label}</div> : null}
        {description ? <div style={{ font: 'var(--type-body-sm)', color: 'var(--text-muted)' }}>{description}</div> : null}
      </span> : null}
    </div>
  );
}
