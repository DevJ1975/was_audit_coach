/**
 * Single-choice radio list.
 */
export interface RadioGroupProps {
  options: Array<string | { value: string; label: string; description?: string }>;
  value?: string;
  defaultValue?: string;
  disabled?: boolean;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}
export declare function RadioGroup(props: RadioGroupProps): JSX.Element;
