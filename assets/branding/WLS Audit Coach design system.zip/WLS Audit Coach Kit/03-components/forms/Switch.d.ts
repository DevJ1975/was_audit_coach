/**
 * Toggle switch, optionally as a full settings row.
 */
export interface SwitchProps {
  checked?: boolean;
  defaultChecked?: boolean;
  /** renders a full-width row with the switch at right */
  label?: string;
  description?: string;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
  style?: React.CSSProperties;
}
export declare function Switch(props: SwitchProps): JSX.Element;
